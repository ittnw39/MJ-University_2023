package Caculator;

import java.io.IOException;

public class Calculator { // 명사 = 클래스, 계산기 / 동사를 모아 명사를 만들었다. 계산기는 인티저를 읽어서 더하기와 곱하기를 하는 것이다. 동사의 집합, 구성을 설명한다.
	private static final int CarrageReturn = 0x0d; //static final은 수정불가. 고정.
	//private static final int zero = 0x30;
	
	private int readOperator() throws IOException {
		int code = System.in.read();
		System.in.read();
		System.in.read();// 13이랑 10이 들어가면 계산기 작동안됨.
		return code;
	}
	
	private int readInt() throws IOException{ //동사의 추상화 - 함수
		int number = 0;
		int code = System.in.read();
		
		while(code >= '0' && code <= '9') { 
			
				number = number * 10 + (code - '0');
			
				code = System.in.read();
			
		}
		if(code == CarrageReturn) { //끝났을 때 왜 빠져나왔는지 알아야한다. - 숫자가 아닌것을 쳤지만 괜찮은 것 = 엔터 13
			code = System.in.read();
			return number;
		}else {
			throw new IOException("Not number!"); //숫자입력 아니면 에러가 뜨게 한다.
		}
		
	}
	private int add() throws IOException{
		int number1 = readInt();
        int number2 = readInt();
		int sum = number1 + number2;
		return sum;
	}
	private int multiply() throws IOException{
		int number1 = readInt();
        int number2 = readInt();
		int mul = number1 * number2;
		return mul;
	}
	private int divide() throws IOException{
		int number1 = readInt();
        int number2 = readInt();
		int mul = number1 / number2;
		return mul;
	}
	private int substraction() throws IOException{
		int number1 = readInt();
        int number2 = readInt();
		int mul = number1 - number2;
		return mul;
	}
	
	public void run() {
			try {
				while(true) { //q누르기 전까지 반복
				int result = 0;
				System.out.println("Enter the Operator (q => quit): ");
				int code = readOperator();
				
				if (code == '+') {
					result = add();
				} else if(code == '-'){
					result = substraction();
				}else if(code == '*'){
					result = multiply();
				}else if(code == '/'){
					result = divide();
				}else if(code == 'q') {
					break;
				}
				System.out.println(result);
				}
			} catch (IOException e) { //위는 계산, 아래는 에러처리를 해야한다.
				e.printStackTrace();
			} catch (ArithmeticException e) { //정수를 0으로 나눌 경우 에러발생
				e.printStackTrace();
			} catch(IllegalArgumentException e) { // +, -, * 가 아닌 연산자가 들어왔을 때
				System.out.println("Not operator");
			}
	}
}


