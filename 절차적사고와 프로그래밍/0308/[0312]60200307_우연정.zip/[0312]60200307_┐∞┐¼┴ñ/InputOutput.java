import java.util.Scanner;

public class InputOutput {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		while(true)
		{
			String i = in.nextLine();
			if(i.equals("x")) {
				System.out.println("종료되었습니다.");
				break;
			}
			
			System.out.println(i);
		}
	}
}

