package valueObject;

public class VIndex {
	private int code;
	private String name;
	private String filename;
}
