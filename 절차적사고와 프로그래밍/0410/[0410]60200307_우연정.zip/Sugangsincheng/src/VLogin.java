import java.util.Scanner;

public class VLogin { //메타 오브젝트

	public boolean login() {
		Scanner sc = new Scanner(System.in); //스캐너랑 키보드 연결. 다 쓰면 돌려줘야 함. 독점적으로 내가 쓸 수 있어야 함.
		
		System.out.println("아이디는 학번 8자리를 입력해주세요.");
		String userID = sc.next();
		System.out.println("ID: " + userID);
		
		System.out.println("비밀번호를 입력하세요.(영대소문자, 숫자, 기호 모두 가능)");
	    String userPW = sc.next();
	    System.out.println("PASSWORD: " + userPW);
	    
	    if (userID.matches("^[0-9]{8}$") && userPW.matches("^[a-zA-Z0-9!@#$%^&*()-=_+\\\\\\\\|\\\\[\\\\]{};':\\\"<>,.?/]+$")) { //아이디는 숫자8자리, 영대소문자는 
	        System.out.println("로그인 되었습니다.");
	        sc.close();
	        return true;  // 로그인됨
	    } else {
	        System.out.println("아이디와 비밀번호를 정확하게 입력하세요.");
	        sc.close();
	        return false; // 로그인 실패
	}

}
}
