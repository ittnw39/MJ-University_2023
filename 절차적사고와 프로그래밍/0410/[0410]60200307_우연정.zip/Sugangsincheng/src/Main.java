
public class Main {
	
	public Main(){
		
	}
	//constructor //뉴 하면 만들어지는 것. 
	private void run() {
		VLogin vlogin = new VLogin();
		
		if(vlogin.login()) {
			Vsugangsincheng vsugangsincheng = new Vsugangsincheng();
			vsugangsincheng.run();
		}
	}
	
	public static void main(String[] args) { //4단계, 메인하고 관계없음. 바깥에 있는 경우도 있다.
		// object name declaration();
		// 메모리 얼로케이션
		// invoke constructor
		// 메모리 주소와 이름 바인딩.
		Main main = new Main(); //오브젝트의 주소를 담을 것이다, 객체를 만들어내서 주소를 반환하여 어싸인하면 주소가 메인이라는 것 안에 들어간다. 함수 호출.
		main.run();
	}

}
