package hw;

import java.io.IOException;

public class ASCII2 {

	public static void main(String[] args) {
		try {
			int number = 0;
			int code = System.in.read();
			if(code > 0*39 || code < 0*30) {
				System.out.println("! only number !");
				}
				while(code != 0*0d) {
				number = number * 10 + (code - 0*30);
				System.out.println(number);
				code = System.in.read();
			
			}System.out.println(number);
			
	}catch(IOException e){
		e.printStackTrace();
		
	}
}
}