package Presentation;

import java.awt.Color;
import java.util.Scanner;
import javax.swing.JPanel;
import valueObject.VLecture;
import valueObject.VUserInfo;

public class PSugangsincheng extends JPanel{

private PLectureSelection pLectureSelection;
private PLectureBasket pMiridamgiBasket;
private PLectureBasket pSinchengBasket;
 
 public PSugangsincheng() {
	 //initialize attributes
	 this.setBackground(Color.BLUE);
	 
	 //add child components
	 this.pLectureSelection = new PLectureSelection();
	 this.pMiridamgiBasket = new PLectureBasket();
	 this.pSinchengBasket = new PLectureBasket();
	 
	 this.add(pLectureSelection);

 }

public void run(VUserInfo vuserinfo, Scanner keyboard) {
	VLecture vLecture = null;
	boolean BRunning = true;
	while(true) {
		System.out.println("강좌 선택 0, 미리담기 1, 수강신청 2, 종료 9");
		
		String sCode = keyboard.next();
		int iCode = Integer.parseInt(sCode);
		switch(iCode) {
		case 0:
			vLecture = pLectureSelection.selectLecture(vuserinfo, keyboard);
			break;
		case 1:
			pMiridamgiBasket.add(vLecture);
			pMiridamgiBasket.show();
			vLecture = null;
			break;
		case 2:
			break;
		case 9:
			BRunning = false;
			break;
		default:
				break;
		}
		
	
	
	}
}
}