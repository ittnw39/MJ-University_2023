package Caculator;

import java.util.Scanner;
import java.util.Stack;

public class prefix {

    public static void main(String[] args) { //prefix 식 입력받기
        Scanner scanner = new Scanner(System.in);
        String expression = "";
        
        while (!expression.equals("q")) { 
            System.out.print("Enter a prefix expression. (ex) + 4 5 | q => quit): "); //q를 입력하면 계산기 종료,
            expression = scanner.nextLine();
            
        if (!expression.equals("q")) {
        try {
            double result = calPrefixExpression(expression);
            System.out.println("Result: " + result);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage()); //입력한 식이 유효한지 확인, 예외 발생.
       }
      }
     }
    }
  
        
    public static double calPrefixExpression(String expression) throws Exception {
        Stack<Double> stack = new Stack<Double>(); 
        String[] tokens = expression.split("[ \n\t]+"); // 문자열로 입력된 식을 공백, 탭, 엔터을 기준으로 토큰으로 나누고 배열에 저장.

        if (tokens[tokens.length - 1].equals("=")) { // 토큰의 마지막 부분이 '='일 때.
            expression = expression.substring(0, expression.length() - 1); // 입력한 문자열의 마지막 부분 '='을 빼고 다시 할당함.
            tokens = expression.split("[ \n\t]+"); //바꾼 문자열을 공백, 탭, 엔터를 기준으로 토큰으로 나눠 배열에 저장.
        }
        
        for (int i = tokens.length - 1; i >= 0; i--) { //배열의 뒤에서부터 하나씩 꺼내서 처리하는 반복문.
            
        	String token = tokens[i]; //토큰을 꺼내온다.
            
            if (isOperator(token)) { // 꺼낸 토큰이 연산자인지 확인.
                double operand1 = stack.pop(); //스택에서 피연산자1을 가져옴.
                double operand2 = stack.pop(); //스택에서 피연산자2를 가져옴.
                double result = calOperator(token, operand1, operand2); //피연산자1, 피연산자2, 연산자를 calOperater 함수에 넣고 그 결과를 result에 저장.
                stack.push(result); //계산 결과를 스택에 저장한다.
            } else if (isNumber(token)) { //꺼내온 토큰이 숫자인 경우 실수 형으로 변횐되고, 스택에 저장.
                stack.push(Double.parseDouble(token));
            } else {
                throw new Exception("Not number or operator : " + token); // 꺼낸 토큰이 연산자나 숫자가 아닌 경우
            }
        }

        if (stack.size() != 1) { //계산 결과가 한 개의 값으로 나오지 않으면 잘못된 식임을 알려줌.
            throw new Exception("Wrong expression : " + expression);
        }

        return stack.pop(); //스택 맨 위의 값을 반환하고 스택에서 삭제.
    }

    private static boolean isOperator(String token) { //꺼낸 문자열 토큰이 연산자와 같은지 비교하고 같으면 그대로 반환한다.
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/"); 
    }

    private static boolean isNumber(String token) { //토큰이 문자열이거나 '='이면 참을 반환한다.
        try {
        	Double.parseDouble(token);
            return true;
           
        } catch (NumberFormatException e) {
        	if (token.equals("=")) {
                return true;
            }
            return false;
        }
    }

    private static double calOperator(String operator, double operand1, double operand2) { // 연산자의 종류에 따라 계산. 실수로 계산하기.
        switch (operator) { 
            case "+":
                return operand1 + operand2;
            case "-":
                return operand1 - operand2;
            case "*":
                return operand1 * operand2;
            case "/":
                return operand1 / operand2;
            default: //사칙연산을 제외한 연산자가 들어오는 경우.
                throw new IllegalArgumentException("Non-existent operators : " + operator);
        }
    }
}