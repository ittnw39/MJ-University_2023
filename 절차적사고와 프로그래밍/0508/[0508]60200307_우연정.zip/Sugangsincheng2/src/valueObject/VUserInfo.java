package valueObject;

public class VUserInfo { //account에서 돌아오는 정보
	private String name;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
