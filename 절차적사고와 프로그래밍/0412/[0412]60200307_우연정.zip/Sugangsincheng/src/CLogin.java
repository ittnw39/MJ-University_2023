import java.io.FileNotFoundException;

public class CLogin { //v를 위한 전용 워커.

	public VUserInfo login(VLogin vlogin) throws FileNotFoundException {
		// TODO Auto-generated method stub
		MAcount macount = new MAcount();
		VUserInfo vuserinfo = macount.login(vlogin);
		return vuserinfo;
	}

}
