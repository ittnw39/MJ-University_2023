import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Psugangsincheng {

public void run() {
		
		List<String[]> courses = new ArrayList<>();
        String fileName = "data/GwamokList.txt"; // 과목정보가 들어있는 파일 읽어오기

        try (BufferedReader br = new BufferedReader(new FileReader("data/GwamokList"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(","); // 한줄씩 읽어서 쉼표로 분리하고 리스트에 저장
                courses.add(data);
            }

            System.out.println("---------- 과목 리스트 ----------");
            for (String[] course : courses) {
                String subject = course[0].trim();
                String time = course[1].trim();
                String credit = course[2].trim();
                String max = course[3].trim();
                
                System.out.println( subject + " | " + time + " | " + credit + "학점 | " + max + "명");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	}

