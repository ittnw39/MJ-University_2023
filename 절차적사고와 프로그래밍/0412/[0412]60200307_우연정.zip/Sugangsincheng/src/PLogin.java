import java.io.FileNotFoundException;
import java.util.Scanner;

public class PLogin { //presentation 화면

	public VUserInfo login() throws FileNotFoundException {
		Scanner sc = new Scanner(System.in); //스캐너랑 키보드 연결. 다 쓰면 돌려줘야 함. 독점적으로 내가 쓸 수 있어야 함.
		
		System.out.println("아이디를 입력하세요.");
		String userID = sc.next();
		System.out.println("비밀번호를 입력하세요.");
	    String userPW = sc.next();
	    sc.close();
	    
	    VLogin vlogin = new VLogin(); //value object에 담기
	    vlogin.setUserID(userID); //vlogin에 아이디 담기
	    vlogin.setUserPW(userPW); //vlogin에 비밀번호 담기
	    
	    CLogin clogin = new CLogin(); 
	    VUserInfo vuserinfo = clogin.login(vlogin);
	    if(vuserinfo==null) {
	    	System.out.println("잘못 입력되었습니다.");
	    }else {
	    	System.out.println(vuserinfo.getName() + "님 안녕하세요.");
	    }
		return vuserinfo;
	}
}
	    /*
	    if (userID.matches("^[0-9]{8}$") && userPW.matches("^[a-zA-Z0-9!@#$%^&*()-=_+\\\\\\\\|\\\\[\\\\]{};':\\\"<>,.?/]+$")) { //아이디는 숫자8자리, 영대소문자는 
	        System.out.println("로그인 되었습니다.");
	        sc.close();
	        return true;  // 로그인됨
	    } else {
	        System.out.println("아이디와 비밀번호를 정확하게 입력하세요.");
	        sc.close();
	        return false; // 로그인 실패
	}

}*/
